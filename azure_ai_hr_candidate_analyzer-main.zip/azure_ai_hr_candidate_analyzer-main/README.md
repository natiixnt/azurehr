# azure_ai_hr_candidate_analyzer


Dependencies

Pakiety niezbędne, aby aplikacja działała w przeglądarce użytkownika.

>react

>react-dom

>axios (Do komunikacji z backendem API)

>react-router-dom (Do zarządzania widokami/stronami)

>react-dropzone (Do przesyłania plików CV)



DevDependencies

>vite

>@vitejs/plugin-react

>typescript

>@types/react

>@types/react-dom

>tailwindcss

>postcss

>autoprefixer
